"""Communication Health Score — 0–100 with four sub-scores.

    responsiveness  (35%)  how many questions actually got answers
    closure         (25%)  how many topic threads were closed with a decision
    inclusion       (20%)  balanced participation (entropy) minus ignored turns
    tone            (20%)  lexical frustration / urgency / uncertainty cues
"""

from __future__ import annotations

import math

from .detectors.unresolved import segment_topics
from .models import Act, GapType, Utterance
from .tone import tone_of

WEIGHTS = {
    "responsiveness": 0.35,
    "closure": 0.25,
    "inclusion": 0.20,
    "tone": 0.20,
}

_TONE_PENALTY = {"frustration": 12, "urgency": 6, "uncertainty": 4}
_IGNORED_PENALTY = 8


def grade_for(score: float) -> str:
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    if score >= 50:
        return "D"
    return "F"


def _responsiveness(utterances: list[Utterance], unanswered_ranges) -> tuple[float, dict]:
    questions = [u for u in utterances if u.act in (Act.QUESTION, Act.CLARIFY)]
    if not questions:
        return 100.0, {"questions": 0, "unanswered": 0}
    unanswered = sum(
        1
        for q in questions
        if any(lo <= q.id <= hi for lo, hi in unanswered_ranges)
    )
    answered = len(questions) - unanswered
    return 100.0 * answered / len(questions), {
        "questions": len(questions),
        "unanswered": unanswered,
    }


def _closure(utterances: list[Utterance]) -> tuple[float, dict]:
    threads = segment_topics(utterances)
    if not threads:
        return 100.0, {"threads": 0, "closed": 0}
    closed = 0
    for lo, hi in threads:
        if any(u.act == Act.CLOSURE for u in utterances[lo : hi + 1]):
            closed += 1
        elif hi + 1 < len(utterances) and utterances[hi + 1].act == Act.CLOSURE:
            closed += 1
    return 100.0 * closed / len(threads), {
        "threads": len(threads),
        "closed": closed,
    }


def _inclusion(utterances: list[Utterance], n_ignored: int) -> tuple[float, dict]:
    counts: dict[str, int] = {}
    for u in utterances:
        counts[u.speaker] = counts.get(u.speaker, 0) + 1
    total = sum(counts.values())
    if total == 0 or len(counts) <= 1:
        balance = 100.0
    else:
        h = -sum(
            (c / total) * math.log(c / total) for c in counts.values()
        ) / math.log(len(counts))
        balance = 100.0 * h
    score = max(0.0, balance - n_ignored * _IGNORED_PENALTY)
    return score, {"speakers": len(counts), "ignored": n_ignored}


def _tone(utterances: list[Utterance]) -> tuple[float, dict]:
    penalty = 0.0
    counts = {"frustration": 0, "urgency": 0, "uncertainty": 0}
    for u in utterances:
        t = tone_of(u.text)
        if t in counts:
            counts[t] += 1
            penalty += _TONE_PENALTY[t]
    score = max(0.0, 100.0 - min(penalty, 70.0))
    return score, counts


def compute_health(
    utterances: list[Utterance],
    gaps: list | None = None,
) -> dict:
    """Return the health report dict for a conversation."""
    gaps = gaps or []
    unanswered_ranges = [
        g.turn_range for g in gaps if g.type is GapType.UNANSWERED_QUESTION
    ]
    n_ignored = sum(1 for g in gaps if g.type is GapType.IGNORED_RESPONSE)

    resp, resp_d = _responsiveness(utterances, unanswered_ranges)
    clos, clos_d = _closure(utterances)
    incl, incl_d = _inclusion(utterances, n_ignored)
    tone, tone_d = _tone(utterances)

    subs = {
        "responsiveness": round(resp),
        "closure": round(clos),
        "inclusion": round(incl),
        "tone": round(tone),
    }
    overall = round(sum(subs[k] * WEIGHTS[k] for k in WEIGHTS))
    return {
        "overall": overall,
        "grade": grade_for(overall),
        "subscores": subs,
        "details": {
            "responsiveness": resp_d,
            "closure": clos_d,
            "inclusion": incl_d,
            "tone": tone_d,
        },
    }
