"""Per-turn sentiment polarity for the emotion-trajectory chart.

Blend of TextBlob polarity (offline) with our lexical tone cues, so affect
markers like "Hello? Anyone?" (which TextBlob scores as neutral) still show
up as a mood dip.
"""

from __future__ import annotations

from .models import Gap, Utterance
from .tone import tone_of

try:
    from textblob import TextBlob
except Exception:  # pragma: no cover
    TextBlob = None  # type: ignore

_LEXICON_POLARITY = {
    "frustration": -0.6,
    "urgency": -0.3,
    "uncertainty": -0.25,
    "neutral": 0.0,
}

_TEXTBLOB_WEIGHT = 0.55
_LEXICON_WEIGHT = 0.45


def polarity(text: str) -> float:
    """Sentiment polarity in [-1, 1] for one message."""
    tb = 0.0
    if TextBlob is not None:
        try:
            tb = float(TextBlob(text).sentiment.polarity)
        except Exception:
            tb = 0.0
    lex = _LEXICON_POLARITY.get(tone_of(text), 0.0)
    blended = _TEXTBLOB_WEIGHT * tb + _LEXICON_WEIGHT * lex
    return max(-1.0, min(1.0, blended))


def sentiment_series(utterances: list[Utterance]) -> list[dict]:
    """One record per turn: {turn, speaker, polarity}."""
    return [
        {"turn": u.id, "speaker": u.speaker, "polarity": round(polarity(u.text), 3)}
        for u in utterances
    ]


def mood_delta(utterances: list[Utterance], lo: int, hi: int) -> float | None:
    """Polarity change from before the gap to inside the gap.

    Positive = mood improved, negative = mood dipped during the gap.
    """
    before = [polarity(u.text) for u in utterances if lo - 2 <= u.id < lo]
    during = [polarity(u.text) for u in utterances if lo <= u.id <= hi]
    if not before or not during:
        return None
    return round(sum(during) / len(during) - sum(before) / len(before), 3)
