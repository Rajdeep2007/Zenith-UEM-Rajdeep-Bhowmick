"""Detector 4: a topic is discussed but never reaches a decision/closure.

Topics are segmented by content-word continuity: a turn that shares no content
words with the running topic vocabulary opens a new thread. A thread is
"unresolved" when it is substantive, contains decision-relevant language or an
open question, and never hits a CLOSURE act.
"""

from __future__ import annotations

from ..evidence import DECISION_WORDS
from ..models import Act, Gap, GapType, Utterance
from ..textutil import content_words
from ..tone import tone_for_turns


def segment_topics(utterances: list[Utterance]) -> list[tuple[int, int]]:
    """Return (start_idx, end_idx) index ranges — one per topic thread."""
    threads: list[tuple[int, int]] = []
    start = 0
    vocab: set[str] = set()
    for i, u in enumerate(utterances):
        words = content_words(u.text)
        if not words:
            continue  # "ok", "mm-hm" continue the current thread
        if not vocab:
            vocab |= words
            continue
        if words & vocab:
            vocab |= words
            continue
        # no shared content word -> new topic
        threads.append((start, i - 1))
        start = i
        vocab = set(words)
    if start < len(utterances):
        threads.append((start, len(utterances) - 1))
    return threads


def detect(
    utterances: list[Utterance],
    claimed: list[tuple[int, int]] | None = None,
    min_turns: int = 4,
) -> list[Gap]:
    gaps: list[Gap] = []
    if not utterances:
        return gaps

    claimed_ids: set[int] = set()
    for lo, hi in claimed or []:
        claimed_ids.update(range(lo, hi + 1))

    for lo, hi in segment_topics(utterances):
        thread = utterances[lo : hi + 1]
        if len(thread) < min_turns:
            continue
        # another detector already explains this span -> don't double-report
        if any(u.id in claimed_ids for u in thread):
            continue
        if any(u.act == Act.CLOSURE for u in thread):
            continue
        # a topic often closes on the very next turn, right as the chat moves on
        nxt = utterances[hi + 1] if hi + 1 < len(utterances) else None
        if nxt is not None and nxt.act == Act.CLOSURE:
            continue
        texts = [u.text for u in thread]
        has_decision = any(DECISION_WORDS.search(t) for t in texts)
        has_question = any(u.act == Act.QUESTION for u in thread)
        if not (has_decision or has_question):
            continue  # casual chatter, not a work thread

        involved = list(dict.fromkeys(u.speaker for u in thread))
        severity = score(thread, has_decision, has_question)
        gaps.append(
            Gap(
                type=GapType.UNRESOLVED_TOPIC,
                turn_range=(thread[0].id, thread[-1].id),
                participants=involved,
                evidence_quotes=[texts[0], texts[-1]],
                message_ids=[thread[0].id, thread[-1].id],
                severity=severity,
                description=(
                    f"Topic opened at turn {thread[0].id} and last touched at "
                    f"turn {thread[-1].id} ({len(thread)} turns, "
                    f"{', '.join(involved)}) was never closed with a decision."
                ),
                tone=tone_for_turns(texts),
            )
        )
    return gaps


def score(thread: list[Utterance], has_decision: bool, has_question: bool) -> "object":
    from ..evidence import score_severity

    texts = [u.text for u in thread]
    return score_severity(
        gap_turns=len(thread),
        silence=len(thread),
        repeats=1 if has_question else 0,
        texts=texts,
    )
