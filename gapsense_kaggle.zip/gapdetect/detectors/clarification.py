"""Detector 3: the same point is clarified/asked about repeatedly, never resolved."""

from __future__ import annotations

from ..evidence import score_severity
from ..models import Act, Gap, GapType, Utterance
from ..textutil import content_words, overlap_score
from ..tone import tone_for_turns


def detect(
    utterances: list[Utterance],
    window: int = 6,
    min_cluster: int = 2,
    similarity: float = 0.5,
) -> list[Gap]:
    gaps: list[Gap] = []
    clarify_idx = [i for i, u in enumerate(utterances) if u.act == Act.CLARIFY]
    if len(clarify_idx) < min_cluster:
        return gaps

    # cluster clarifications that are close together AND about the same thing
    clusters: list[list[int]] = []
    for i in clarify_idx:
        words = content_words(utterances[i].text)
        placed = False
        for cl in clusters:
            last_i = cl[-1]
            if i - last_i > window:
                continue
            ref = content_words(utterances[last_i].text)
            if overlap_score(words, ref) >= similarity or (words & ref):
                cl.append(i)
                placed = True
                break
        if not placed:
            clusters.append([i])

    for cl in clusters:
        if len(cl) < min_cluster:
            continue
        turns = [utterances[i] for i in cl]
        start, end = turns[0].id, turns[-1].id

        # is it actually resolved? a CLOSURE between first and last clarify = resolved
        between = [
            u for u in utterances if start <= u.id <= end and u.act == Act.CLOSURE
        ]
        if between:
            continue

        involved = list(dict.fromkeys(u.speaker for u in turns))
        texts = [u.text for u in turns]
        severity = score_severity(
            gap_turns=end - start,
            silence=len(cl) - 1,
            repeats=len(cl) - 1,
            texts=texts,
        )
        gaps.append(
            Gap(
                type=GapType.REPEATED_CLARIFICATION,
                turn_range=(start, end),
                participants=involved,
                evidence_quotes=texts,
                message_ids=[t.id for t in turns],
                severity=severity,
                description=(
                    f"The same point was asked about {len(cl)} times "
                    f"(turns {start}-{end}) by {', '.join(involved)} and was "
                    f"never resolved."
                ),
                tone=tone_for_turns(texts),
            )
        )
    return gaps
