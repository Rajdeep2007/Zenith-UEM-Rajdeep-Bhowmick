"""gapdetect — detect communication gaps in multi-person conversations."""

from .models import Act, Gap, GapType, Report, Severity, Utterance
from .pipeline import analyze, analyze_utterances

__version__ = "1.0.0"
__all__ = [
    "Act",
    "Gap",
    "GapType",
    "Report",
    "Severity",
    "Utterance",
    "analyze",
    "analyze_utterances",
]
