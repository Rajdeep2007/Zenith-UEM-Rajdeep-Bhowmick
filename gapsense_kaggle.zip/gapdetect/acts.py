"""Rule-based dialogue-act tagging.

Labels: QUESTION, CLARIFY, ANSWER, CLOSURE, STATEMENT
"""

from __future__ import annotations

import re

from .models import Act, Utterance
# explicit interrogative starters / helpers
_STARTERS = re.compile(
    r"^(?:can|could|should|would|will|shall|do|does|did|is|are|was|were|"
    r"has|have|had|may|might|anyone|anybody|someone|somebody|everyone|"
    r"nobody|team|guys|all|please)\b",
    re.IGNORECASE,
)

_HWS = re.compile(
    r"\b(?:who|what|when|where|why|which|how|whose|whom)\b", re.IGNORECASE
)

_CLARIFY_RE = re.compile(
    r"\b(?:what\s+do\s+you\s+mean|can\s+you\s+clarify|clarify|"
    r"i\s+(?:didn'?t|did not)\s+(?:understand|get)|"
    r"could\s+you\s+(?:explain|rephrase|elaborate)|"
    r"can\s+you\s+(?:explain|rephrase|elaborate|repeat|clarify)|"
    r"what\s+(?:exactly|precisely|does\s+\w+\s+mean)|"
    r"i'?m\s+(?:a\s+bit\s+)?(?:confused|lost|unsure)|"
    r"not\s+sure\s+(?:what|how|why)|"
    r"say\s+that\s+again|come\s+again|"
    r"can\s+someone\s+(?:explain|clarify)|"
    r"to\s+clarify|just\s+to\s+be\s+clear|"
    r"what\s+does\s+(?:that|this|it)\s+mean|"
    r"i\s+(?:don'?t|do not)\s+(?:follow|understand))",
    re.IGNORECASE,
)

_CLOSURE_RE = re.compile(
    r"\b(?:so\s+(?:we\s+)?(?:are\s+)?(?:all\s+)?agreed|"
    r"we\s+(?:are\s+)?agreed|"
    r"(?:to\s+)?(?:summar(?:y|ize)|summing\s+up)|"
    r"final\s+(?:decision|call|word)|"
    r"let'?s\s+(?:lock|confirm|close|go\s+with)|"
    r"decision\s+(?:is|made)|"
    r"we\s+(?:will|shall|are\s+going\s+to)\s+"
    r"(?:go\s+with|use|ship|proceed)|"
    r"agreed|approved|sign[ -]?off|"
    r"action\s+item|"
    r"to\s+conclude|in\s+conclusion)",
    re.IGNORECASE,
)

_ANSWER_RE = re.compile(
    r"^(?:yes|no|yeah|nope|sure|ok(?:ay)?|right|correct|"
    r"it'?s|it\s+is|it\s+was|they'?re|the\s+answer|"
    r"i\s+(?:think|believe|thought|remember|recall|guess|know|finished|"
    r"have|had|would|will|can|tested|checked|fixed|see|mean)|"
    r"we\s+(?:should|can|will|need)|"
    r"because|since|according\s+to)",
    re.IGNORECASE,
)

_ACK_RE = re.compile(
    r"^(?:got\s+it|makes\s+sense|noted|thanks|thank\s+you|"
    r"fair\s+enough|good|great|cool|ack|acknowledged|"
    r"i\s+see|understood)\b",
    re.IGNORECASE,
)


def _has_question_cue(text: str) -> bool:
    t = text.strip()
    if not t:
        return False
    if t.endswith("?"):
        # "? " anywhere or trailing -> interrogative
        return True
    if _HWS.search(t) and _STARTERS.search(t):
        return True
    # "I was wondering ..." style
    if re.search(r"\b(?:wondering|wonder|asking)\b", t, re.IGNORECASE):
        return True
    return False


def tag_act(u: Utterance) -> Act:
    """Classify a single utterance."""
    t = u.text.strip()

    if _CLARIFY_RE.search(t):
        return Act.CLARIFY
    # a turn ending in '?' (or a wh-word + interrogative starter) is a question,
    # even if it happens to contain closure words like "approved"
    if _has_question_cue(t):
        return Act.QUESTION
    if _CLOSURE_RE.search(t):
        return Act.CLOSURE
    if _ACK_RE.search(t):
        return Act.ANSWER
    if _ANSWER_RE.search(t):
        return Act.ANSWER
    return Act.STATEMENT


def tag(utterances: list[Utterance]) -> list[Utterance]:
    """Tag every utterance in place and return the list."""
    for u in utterances:
        u.act = tag_act(u)
    return utterances
