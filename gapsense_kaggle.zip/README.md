# Communication Gap Detector — CEREBRO, IEM Kolkata

Analyses a multi-person conversation, finds **communication gaps**, shows
**where** they happened in the transcript, and quotes **verbatim evidence**.

## Gap types

| Type | What it catches |
|------|-----------------|
| `unanswered_question` | A question that receives no reply inside the reply window |
| `ignored_response` | An answer/statement nobody references or acknowledges |
| `repeated_clarification` | The same point re-asked ≥ 2 times, never resolved |
| `unresolved_topic` | A topic discussed but never closed with a decision |

Each gap also carries a **severity** (high/medium/low) and a **tone cue**
(frustration / urgency / uncertainty / neutral) from lexical affect markers.

## Quick start

```bash
streamlit run app.py      # interactive demo
python eval.py            # precision / recall / F1 vs ground truth
python train.py           # (re)train the confidence classifier on synthetic gaps
```

No API keys, no model downloads — pure Python + Streamlit.
The classifier artifact (`artifacts/gap_classifier.joblib`) is optional:
without it the app just hides the confidence badges.

## Using it

1. Pick a demo conversation in the sidebar (**Team Standup**, **Design Review**,
   **Clean Meeting**) or choose **Paste your own** and enter `Speaker: text` lines.
2. Adjust the **reply window** (how many turns of silence count as a gap).
3. Read the **Highlighted transcript** tab — every gap turn is color-coded.
4. Open **Gap report** for evidence cards (verbatim quotes + cited message IDs +
   model confidence), **Emotion** for the sentiment trajectory, or **JSON** to
   download the report.

## Example output

```json
{
  "title": "Team Standup",
  "summary": {"total": 4, "by_type": {"unanswered_question": 1, "ignored_response": 2, "repeated_clarification": 1, "unresolved_topic": 0}},
  "gaps": [
    {
      "type": "unanswered_question",
      "turn_range": [4, 7],
      "participants": ["Alice"],
      "evidence_quotes": ["Good. Does anyone know if the staging environment is back up?", "Hello? Is staging up? Anyone?"],
      "tone": "frustration",
      "severity": "medium",
      "description": "Question(s) from Alice starting at turn 4 received no reply for 3 turn(s)."
    }
  ]
}
```

## How it works

```
transcript → ingest → dialogue-act tagging → 4 detectors → evidence check → report
```

1. **Ingest** parses `Speaker: text` lines (or JSON) into turns.
2. **Act tagging** labels each turn: `QUESTION`, `CLARIFY`, `ANSWER`,
   `CLOSURE`, `STATEMENT` (regex + lexical cues).
3. **Detectors** run independently over turn windows:
   - unanswered — question → look ahead for a real response (answer act,
     commitment cue, or ≥25% content-word overlap)
   - ignored — an answer/addressed statement with no reference or ack from
     other speakers in the window
   - clarification — re-asked questions clustered by content-word overlap,
     skipped if a closure act appears between them
   - unresolved — topics segmented by content-word continuity; flagged when
     substantive, decision-relevant, and never closed
4. **Evidence verification** — every quote must be a verbatim substring of the
   source transcript, otherwise it is dropped: *no invented evidence, ever*.
5. **Severity** — score from silence length, repeat count and decision keywords.

## Evaluation

`python eval.py` runs all three labelled transcripts:

```
TOTAL   TP=6  FP=0  FN=0
Precision=1.000  Recall=1.000  F1=1.000
```

- 3 transcripts with hand-injected gaps + **Clean Meeting** as a
  false-positive control (expected output: zero gaps).
- Matching: predicted vs labelled gap of the **same type** whose turn ids intersect.

## Layout

```
gapdetect/
  models.py      Utterance, Gap, Report, enums
  ingest.py      transcript parsing
  acts.py        dialogue-act tagging
  tone.py        affect/lexical tone cues
  evidence.py    verbatim quote verification + severity scoring
  textutil.py    tokenising, stemming, overlap scoring
  pipeline.py    end-to-end analyse()
  detectors/     unanswered, ignored, clarification, unresolved
data/            3 demo transcripts + ground_truth/
app.py           Streamlit demo
eval.py          P/R/F1 evaluation
PROJECT.md       full project write-up (for slides/README)
```

## Acknowledgements

- **ParShift** — [bdfsaraiva/parshift](https://github.com/bdfsaraiva/parshift) (**MIT**),
  used for the participation-shift / turn-taking layer.
  Ferreira-Saraiva, B.D., Matos-Carvalho, J.P., Fachada, N. & Pita, M. (2023).
  *ParShift: A Python package to study order and differentiation in group
  conversations.* SoftwareX 24, 101554. https://doi.org/10.1016/j.softx.2023.101554
- **Gibson's (2003) participation-shift framework** — the theory behind the
  speaker/target/non-target turn codes.
- Inspirations (no code used): *groupchat-decoder* (dashboard feature set),
  *Agreement-and-Disagreement-Recognition* (agree/disagree signal idea),
  *chat-analytics* (chat export parsing approach).

## Extending

- Add a detector: drop a module in `gapdetect/detectors/` returning `list[Gap]`,
  wire it into `pipeline.py`.
- New demo transcript: add `data/<name>.json` + `data/ground_truth/<name>.json`.
- LLM assist: `analyze()` output can be fed to a model for adjudication — the
  verbatim evidence check keeps outputs grounded.
